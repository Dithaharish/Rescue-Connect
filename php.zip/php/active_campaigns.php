<?php
session_start();
if ($_SESSION['user_role'] !== 'citizen') {
    header("Location: ../login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Active Campaigns - Donor Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 20px;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand {
            color: white;
        }
        .btn-custom {
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            margin-top: 10px;
            padding: 12px 20px;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
        .container {
            max-width: 900px;
            margin-top: 50px;
        }
        .campaign-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 10px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .campaign-card h4 {
            color: #007bff;
        }
        .campaign-card p {
            font-size: 16px;
        }
        .donate-btn {
            background-color: #28a745;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
        }
        .donate-btn:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <?php include 'role_navbar.php'; ?>

    <div class="container">
        <h2>Active Fundraising Campaigns</h2>
        <?php
        include 'connect.php';

        // Fetch active campaigns from the database
        $result = $conn->query("SELECT * FROM campaigns WHERE status = 'active'");

        if ($result->num_rows > 0) {
            while ($campaign = $result->fetch_assoc()) {
                echo '<div class="campaign-card">';
                echo '<h4>' . htmlspecialchars($campaign['title']) . '</h4>';
                echo '<p>' . htmlspecialchars($campaign['description']) . '</p>';
                echo '<p><strong>Target Goal:</strong> ' . htmlspecialchars($campaign['goal_amount']) . '</p>';
                echo '<p><strong>Amount Raised:</strong> ' . htmlspecialchars($campaign['raised_amount']) . '</p>';
                echo '<a href="make_donation.php?campaign_id=' . $campaign['id'] . '" class="donate-btn">Donate Now</a>';
                echo '</div>';
            }
        } else {
            echo '<p>No active campaigns at the moment. Please check back later.</p>';
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
