<?php
session_start();
if ($_SESSION['user_role'] !== 'citizen') {
    header("Location: ../login.html");
    exit();
}

include 'connect.php';

// Get the user_id from the session
$user_id = $_SESSION['user_id'];  // Ensure this session variable is set during login

// Fetch the donor's profile details from the database using prepared statements
$query = "SELECT * FROM donors WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);  // Bind the user_id parameter
$stmt->execute();
$result = $stmt->get_result();
$donor = $result->fetch_assoc();

// Close the database connection
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Donor Profile - Donor Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 20px;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand {
            color: white;
        }
        .container {
            max-width: 900px;
            margin-top: 50px;
        }
        .profile-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 10px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .profile-card h3 {
            color: #007bff;
        }
        .profile-card p {
            font-size: 16px;
        }
        .btn-custom {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 10px;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <?php include 'role_navbar.php'; ?>

    <div class="container">
        <h2>Your Profile</h2>
        <?php if ($donor): ?>
            <div class="profile-card">
                <h3><?= htmlspecialchars($donor['name']); ?>'s Profile</h3>
                <p><strong>Email:</strong> <?= htmlspecialchars($donor['email']); ?></p>
                <p><strong>Address:</strong> <?= htmlspecialchars($donor['address']); ?></p>
                <p><strong>Phone:</strong> <?= htmlspecialchars($donor['phone']); ?></p>
                <p><strong>Preferred Cause:</strong> <?= htmlspecialchars($donor['preferred_cause']); ?></p>
                <p><strong>Donor Since:</strong> <?= htmlspecialchars($donor['donor_since']); ?></p>

                <!-- New Profile Details -->
                <p><strong>Emergency Contact Name:</strong> <?= htmlspecialchars($donor['emergency_contact_name']); ?></p>
                <p><strong>Emergency Contact Phone:</strong> <?= htmlspecialchars($donor['emergency_contact_phone']); ?></p>
                <p><strong>Rating/Feedback:</strong> <?= htmlspecialchars($donor['rating_feedback']); ?></p>
                <p><strong>Medical Conditions:</strong> <?= htmlspecialchars($donor['medical_conditions']); ?></p>
                <p><strong>First Aid Certification:</strong> <?= htmlspecialchars($donor['first_aid_certification']); ?></p>
                <p><strong>ID Proof:</strong> <?= htmlspecialchars($donor['id_proof']); ?></p>
                <p><strong>Background Check:</strong> <?= htmlspecialchars($donor['background_check']); ?></p>

                <a href="edit_donor_profile.php" class="btn-custom">Edit Profile</a>
            </div>
        <?php else: ?>
            <p>No profile found for this donor.</p>
        <?php endif; ?>
    </div>
</body>
</html>
