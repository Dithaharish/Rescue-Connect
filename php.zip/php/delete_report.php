<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../login.html");
    exit();
}

include 'connect.php';

// Check if the report ID is provided
if (isset($_GET['id'])) {
    $report_id = $_GET['id'];

    // Delete report from database
    $sql = "DELETE FROM reports WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $report_id);

    if ($stmt->execute()) {
        echo "<script>alert('Report deleted successfully'); window.location.href='view_reports.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
    $stmt->close();
    $conn->close();
} else {
    echo "Report ID is missing!";
    exit();
}
?>
