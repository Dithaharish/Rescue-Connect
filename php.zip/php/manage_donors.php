<?php
session_start();
if ($_SESSION['user_role'] !== 'authority') {
    header("Location: ../login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Donors</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'role_navbar.php'; ?>
<div class="container mt-5">
    <h2>Manage Donors</h2>
    <p>View donor profiles, verify donations, and communicate with supporters.</p>
</div>
</body>
</html>
