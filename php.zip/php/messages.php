<?php
session_start();
if (!isset($_SESSION['volunteer_logged_in'])) {
    header("Location: login.php");
    exit();
}
include 'connect.php';

$volunteer_id = $_SESSION['volunteer_id'];
$messages_result = $conn->query("SELECT * FROM messages WHERE recipient_id = '$volunteer_id'");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Messages - Volunteer Dashboard</title>
</head>
<body>
    <h2>Your Messages</h2>
    <ul>
        <?php while ($message = $messages_result->fetch_assoc()): ?>
            <li><?= $message['message']; ?> - From: <?= $message['sender_id']; ?></li>
        <?php endwhile; ?>
    </ul>
</body>
</html>
