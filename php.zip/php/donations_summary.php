<?php
session_start();
if ($_SESSION['user_role'] !== 'authority') {
    header("Location: ../login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Donations Summary</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'role_navbar.php'; ?>
<div class="container mt-5">
    <h2>Donations Summary</h2>
    <p>Track and review donations from citizens across campaigns.</p>
</div>
</body>
</html>
