<?php
session_start();
if ($_SESSION['user_role'] !== 'volunteer') {
    header("Location: ../login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Volunteer Dashboard - Rescue Connect</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'role_navbar.php'; ?>
    <span class="navbar-brand">Welcome Volunteer, <?= htmlspecialchars($_SESSION['user_name']); ?>!</span>
    <a class="btn btn-outline-light" href="user_logout.php">Logout</a>
</nav>

<div class="container text-center mt-5">
    <h1>Volunteer Control Center</h1>
    <p class="lead">Here you can view assigned tasks, manage your profile, and stay updated with disaster zones and events.</p>

    <!-- Buttons for the features -->
    <div class="row">
        <div class="col-12 col-md-4 mb-3">
            <a href="profile.php" class="btn btn-primary btn-block">My Profile</a>
        </div>
        <div class="col-12 col-md-4 mb-3">
            <a href="active_tasks.php" class="btn btn-success btn-block">Active Tasks</a>
        </div>
        <div class="col-12 col-md-4 mb-3">
            <a href="sign_up_task.php" class="btn btn-warning btn-block">Sign Up for Tasks</a>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-md-4 mb-3">
            <a href="upcoming_events.php" class="btn btn-info btn-block">Upcoming Events</a>
        </div>
        <div class="col-12 col-md-4 mb-3">
            <a href="submit_report.php" class="btn btn-danger btn-block">Submit Report</a>
        </div>
        <div class="col-12 col-md-4 mb-3">
            <a href="task_status.php" class="btn btn-dark btn-block">Task Status</a>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-md-4 mb-3">
            <a href="alerts.php" class="btn btn-danger btn-block">Emergency Alerts</a>
        </div>
        <div class="col-12 col-md-4 mb-3">
            <a href="feedback.php" class="btn btn-info btn-block">Provide Feedback</a>
        </div>
        <div class="col-12 col-md-4 mb-3">
            <a href="messages.php" class="btn btn-warning btn-block">Messages</a>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-md-4 mb-3">
            <a href="history.php" class="btn btn-secondary btn-block">Volunteer History</a>
        </div>
    </div>

</div>

</body>
</html>
