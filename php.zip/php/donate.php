<?php
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $donor_name = $_POST['donor_name'];
    $amount = $_POST['amount'];
    $donation_type = $_POST['donation_type'];

    $sql = "INSERT INTO donations (donor_name, amount, donation_type) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sds", $donor_name, $amount, $donation_type);

    if ($stmt->execute()) {
        echo "Thank you for your donation!";
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
