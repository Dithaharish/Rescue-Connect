<?php
session_start();
if ($_SESSION['user_role'] !== 'citizen') {
    header("Location: ../login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Donor Dashboard - Rescue Connect</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background: #f5f9ff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand, .nav-link {
            color: white !important;
        }
        .dashboard-card {
            background: white;
            border: none;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            margin-top: 30px;
        }
        .btn-custom {
            background-color: #007bff;
            color: white;
            margin: 10px;
            width: 100%;
            border-radius: 8px;
            padding: 12px;
            transition: 0.3s ease;
        }
        .btn-custom:hover {
            background-color: #0056b3;
            color: white;
        }
    </style>
</head>
<body>

<?php include 'role_navbar.php'; ?>

<div class="container text-center mt-4">
    <h2 class="text-primary">Welcome Donor, <?= htmlspecialchars($_SESSION['user_name']); ?>!</h2>
    <p class="lead">Choose a feature to explore:</p>

    <div class="dashboard-card">
        <div class="row">
            <div class="col-md-6">
                <a href="donation_summary.php" class="btn btn-custom">1️⃣ Donation Summary</a>
                <a href="active_campaigns.php" class="btn btn-custom">2️⃣ Active Campaigns</a>
                <a href="donor_notifications.php" class="btn btn-custom">3️⃣ Notifications & Alerts</a>
                <a href="make_donation.php" class="btn btn-custom">4️⃣ Make a Donation</a>
                <a href="donation_receipts.php" class="btn btn-custom">5️⃣ Donation Receipts</a>
            </div>
            <div class="col-md-6">
                <a href="donor_profile.php" class="btn btn-custom">6️⃣ Profile Management</a>
                <a href="donor_leaderboard.php" class="btn btn-custom">7️⃣ Leaderboard / Recognition</a>
                <a href="impact_stories.php" class="btn btn-custom">8️⃣ Impact Stories</a>
                <a href="donation_analytics.php" class="btn btn-custom">9️⃣ Analytics</a>
                <a href="contact_support.php" class="btn btn-custom">🔧 10️⃣ Contact Support</a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
