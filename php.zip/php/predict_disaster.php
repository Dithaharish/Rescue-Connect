<?php
$type = "Flood";  // Simulated AI output
$date = date('Y-m-d', strtotime('+3 days'));
$severity = "High";
$location = "Hyderabad";

$conn = new mysqli("localhost", "root", "", "rescue_connect");
$sql = "INSERT INTO disasters (type, predicted_date, severity, location) VALUES ('$type', '$date', '$severity', '$location')";

if ($conn->query($sql) === TRUE) {
    echo "Disaster prediction saved!";
} else {
    echo "Error: " . $conn->error;
}
$conn->close();
?>
