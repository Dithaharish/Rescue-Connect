<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../login.html");
    exit();
}

include 'connect.php';

// Fetch report data if the ID is passed via GET
if (isset($_GET['id'])) {
    $report_id = $_GET['id'];
    
    // Fetch report details from database
    $sql = "SELECT * FROM reports WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $report_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $report = $result->fetch_assoc();
    } else {
        echo "Report not found!";
        exit();
    }
} else {
    echo "Report ID is missing!";
    exit();
}

// Handle form submission to update report
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $status = $_POST['status'];

    // Update report in database
    $sql = "UPDATE reports SET title = ?, description = ?, status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $title, $description, $status, $report_id);

    if ($stmt->execute()) {
        echo "<script>alert('Report updated successfully'); window.location.href='view_reports.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Report - Rescue Connect</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Rescue Connect Admin</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Admin Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="user_logout.php">Logout</a></li>
        </ul>
    </div>
</nav>

<div class="container mt-5">
    <h2 class="text-center mb-4">Edit Report</h2>

    <form method="POST" action="edit_report.php?id=<?= $report['id'] ?>">
        <div class="form-group">
            <label for="title">Report Title</label>
            <input type="text" class="form-control" name="title" id="title" value="<?= $report['title'] ?>" required>
        </div>

        <div class="form-group">
            <label for="description">Report Description</label>
            <textarea class="form-control" name="description" id="description" rows="4" required><?= $report['description'] ?></textarea>
        </div>

        <div class="form-group">
            <label for="status">Status</label>
            <select class="form-control" name="status" id="status" required>
                <option value="pending" <?= $report['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                <option value="in_progress" <?= $report['status'] == 'in_progress' ? 'selected' : '' ?>>In Progress</option>
                <option value="completed" <?= $report['status'] == 'completed' ? 'selected' : '' ?>>Completed</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success">Update Report</button>
    </form>
</div>

<footer class="bg-primary text-white text-center py-3 mt-5">
    &copy; 2025 Rescue Connect | Admin Panel
</footer>

</body>
</html>
