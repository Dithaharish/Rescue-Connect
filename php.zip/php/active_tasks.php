<?php
session_start();
if (!isset($_SESSION['volunteer_logged_in'])) {
    header("Location: login.php");
    exit();
}
include 'connect.php';

// Get the volunteer ID from the session
$volunteer_id = $_SESSION['volunteer_id'];

// Update the query to use 'assigned_volunteer' instead of 'volunteer_id'
$query = "SELECT * FROM tasks WHERE assigned_volunteer = '$volunteer_id' AND status = 'ongoing'";
$result = $conn->query($query);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Active Tasks - Volunteer Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
        }

        h2 {
            text-align: center;
            color: #007bff;
        }

        .task-list {
            list-style-type: none;
            padding: 0;
        }

        .task-item {
            background-color: white;
            padding: 15px;
            margin: 10px 0;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .task-item h3 {
            margin: 0;
            font-size: 18px;
        }

        .task-item p {
            margin: 5px 0;
            font-size: 14px;
        }

        .no-tasks {
            text-align: center;
            color: #888;
        }

        footer {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: absolute;
            bottom: 0;
            width: 100%;
        }

        nav {
            background-color: #007bff;
        }

        nav ul {
            padding: 0;
            margin: 0;
            list-style-type: none;
            text-align: right;
        }

        nav ul li {
            display: inline;
            margin: 0 15px;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            padding: 10px 15px;
            display: inline-block;
        }

        nav ul li a:hover {
            background-color: #343a40;
            border-radius: 5px;
        }

        .container {
            padding: 20px;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav>
    <ul>
        <li><a href="volunteer_dashboard.php">Dashboard</a></li>
        <li><a href="active_tasks.php">Active Tasks</a></li>
        <li><a href="profile.php">My Profile</a></li>
        <li><a href="user_logout.php">Logout</a></li>
        <li>
            <button class="btn btn-sm btn-light ml-3" onclick="toggleDarkMode()">
                <i class="bi bi-moon-stars-fill"></i> Dark Mode
            </button>
        </li>
    </ul>
</nav>

<header>
    <h1>Rescue Connect</h1>
    <p>Active Tasks for Volunteer</p>
</header>

<div class="container">
    <h2>Your Active Tasks</h2>

    <?php if ($result->num_rows > 0): ?>
        <ul class="task-list">
            <?php while ($task = $result->fetch_assoc()): ?>
                <li class="task-item">
                    <h3><?= htmlspecialchars($task['task_name']); ?></h3>
                    <p>Status: <?= htmlspecialchars($task['status']); ?></p>
                    <p>Description: <?= htmlspecialchars($task['description']); ?></p>
                </li>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p class="no-tasks">No active tasks found.</p>
    <?php endif; ?>
</div>

<footer>
    <p>&copy; <?= date("Y"); ?> Rescue Connect. All rights reserved.</p>
</footer>

</body>
</html>
