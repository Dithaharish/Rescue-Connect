<?php
session_start();
if (!isset($_SESSION['volunteer_logged_in'])) {
    header("Location: login.php");
    exit();
}
include 'connect.php';

$volunteer_id = $_SESSION['volunteer_id'];
$tasks_result = $conn->query("SELECT * FROM tasks WHERE assigned_volunteer = '$volunteer_id'");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Task History - Volunteer Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f8fb;
            margin: 0;
            padding: 0;
        }
        nav {
            background-color: #007bff;
            padding: 15px;
            display: flex;
            justify-content: center;
        }
        nav a {
            color: white;
            text-decoration: none;
            margin: 0 20px;
            font-weight: bold;
        }
        nav a:hover {
            text-decoration: underline;
        }
        .container {
            max-width: 700px;
            margin: 40px auto;
            background: white;
            padding: 25px 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 20px;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        li {
            background: #e9f2ff;
            margin: 10px 0;
            padding: 12px 20px;
            border-radius: 8px;
            color: #333;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        .no-tasks {
            text-align: center;
            color: #555;
            font-size: 16px;
        }
    </style>
</head>
<body>

<nav>
    <a href="volunteer_dashboard.php">Dashboard</a>
    <a href="active_tasks.php">Active Tasks</a>
    <a href="history.php">Task History</a>
    <a href="alerts.php">Alerts</a>
    <a href="feedback.php">Feedback</a>
    <a href="user_logout.php">Logout</a>
</nav>

<div class="container">
    <h2>Your Task History</h2>
    <?php if ($tasks_result->num_rows > 0): ?>
        <ul>
            <?php while ($task = $tasks_result->fetch_assoc()): ?>
                <li><?= htmlspecialchars($task['task_name']); ?> — Status: <?= htmlspecialchars($task['status']); ?></li>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p class="no-tasks">You have no completed or past tasks at the moment.</p>
    <?php endif; ?>
</div>

</body>
</html>
