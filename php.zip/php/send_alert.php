<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $recipient = $_POST["email"];
    $subject = "Disaster Alert!";
    $message = $_POST["message"];

    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';   // Your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'your-email@gmail.com';    // Your Gmail
        $mail->Password = 'your-app-password';      // Gmail App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        //Recipients
        $mail->setFrom('your-email@gmail.com', 'Rescue Connect Alert');
        $mail->addAddress($recipient);

        //Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        $mail->send();
        echo "Alert sent successfully to $recipient!";
    } catch (Exception $e) {
        echo "Alert could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
