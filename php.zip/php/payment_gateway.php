<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('Invalid CSRF token.');
    }

    include 'connect.php';

    $campaign_id = $_SESSION['campaign_id'];
    $donation_amount = $_SESSION['donation_amount'];
    $donor_name = $_SESSION['donor_name'];
    $donor_email = $_SESSION['donor_email'];
    $donation_message = $_SESSION['donation_message'];
    $payment_method = $_POST['payment_method'] ?? '';

    switch ($payment_method) {
        case 'credit_card':
            if (empty($_POST['card_number']) || empty($_POST['expiry_date']) || empty($_POST['cvv'])) {
                die('Credit card details missing.');
            }
            $payment_note = "Paid via Credit Card.";
            break;

        case 'net_banking':
            if (empty($_POST['bank_name']) || empty($_POST['account_number']) || empty($_POST['ifsc_code'])) {
                die('Net Banking details missing.');
            }
            $payment_note = "Paid via Net Banking.";
            break;

        case 'paypal':
            $payment_note = "Paid via PayPal.";
            break;

        default:
            die('Invalid payment method.');
    }

    $stmt = $conn->prepare("INSERT INTO donations (campaign_id, amount, payment_method, donor_name, donor_email, donation_message, donation_date) VALUES (?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("idssss", $campaign_id, $donation_amount, $payment_method, $donor_name, $donor_email, $payment_note);

    if ($stmt->execute()) {
        unset($_SESSION['donation_amount'], $_SESSION['campaign_id'], $_SESSION['donor_name'], $_SESSION['donor_email'], $_SESSION['donation_message']);
        header("Location: payment_success.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
