<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../login.html");
    exit();
}
include 'connect.php';

// Fetch counts
$volunteers = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'volunteer'")->fetch_row()[0];
$citizens = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'citizen'")->fetch_row()[0];
$authorities = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'authority'")->fetch_row()[0];
$reports = $conn->query("SELECT COUNT(*) FROM reports")->fetch_row()[0]; // Get report count
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Rescue Connect</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Rescue Connect Admin</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link" href="view_volunteers.php">View Volunteers</a></li>
            <li class="nav-item"><a class="nav-link" href="view_citizens.php">View Citizens</a></li>
            <li class="nav-item"><a class="nav-link" href="view_authorities.php">View Authorities</a></li>
            <li class="nav-item"><a class="nav-link" href="view_reports.php">View Reports</a></li>
            <li class="nav-item"><a class="nav-link" href="user_logout.php">Logout</a></li>
        </ul>
    </div>
</nav>

<div class="container mt-5">
    <h2 class="text-center mb-4">Welcome, Admin!</h2>

    <div class="row text-center">
        <div class="col-md-4 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5 class="card-title">Volunteers</h5>
                    <p class="card-text display-4"><?= $volunteers; ?></p>
                    <a href="view_volunteers.php" class="btn btn-primary btn-sm">View</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5 class="card-title">Citizens</h5>
                    <p class="card-text display-4"><?= $citizens; ?></p>
                    <a href="view_citizens.php" class="btn btn-primary btn-sm">View</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5 class="card-title">Authorities</h5>
                    <p class="card-text display-4"><?= $authorities; ?></p>
                    <a href="view_authorities.php" class="btn btn-primary btn-sm">View</a>
                </div>
            </div>
        </div>

        <!-- Reports Section for Admin -->
        <div class="col-md-4 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5 class="card-title">Reports</h5>
                    <p class="card-text display-4"><?= $reports; ?></p>
                    <a href="view_reports.php" class="btn btn-primary btn-sm">View</a>
                    <!-- Add Edit & Delete Buttons for Reports -->
                    <a href="add_report.php" class="btn btn-success btn-sm mt-2">➕ Add Report</a>
                </div>
            </div>
        </div>
    </div>

    <!-- New User Section -->
    <div class="text-center mt-4">
        <a href="add_user.php" class="btn btn-success">➕ Add New User</a>
    </div>

    <!-- User Search Section -->
    <div class="mt-4">
        <h4>Search Users</h4>
        <form method="GET" action="search_users.php">
            <div class="form-row">
                <div class="col-md-4">
                    <input type="text" class="form-control" name="name" placeholder="Name" />
                </div>
                <div class="col-md-4">
                    <input type="email" class="form-control" name="email" placeholder="Email" />
                </div>
                <div class="col-md-4">
                    <select class="form-control" name="role">
                        <option value="">Select Role</option>
                        <option value="volunteer">Volunteer</option>
                        <option value="citizen">Citizen</option>
                        <option value="authority">Authority</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-info mt-3">Search</button>
        </form>
    </div>
</div>

<footer class="bg-primary text-white text-center py-3 mt-5">
    &copy; 2025 Rescue Connect | Admin Panel
</footer>

</body>
</html>
