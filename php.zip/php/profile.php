<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'volunteer') {
    header("Location: login.php");
    exit();
}
include 'connect.php';

$volunteer_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM users WHERE id = '$volunteer_id'");
$volunteer = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['field'])) {
    $field = $_POST['field'];
    $value = $_POST['value'];

    $allowed_fields = [
        'name', 'email', 'phone', 'age', 'address',
        'emergency_contact_name', 'emergency_contact_phone',
        'skills_expertise', 'availability', 'volunteer_history',
        'preferred_task_type', 'languages_spoken', 'medical_conditions',
        'first_aid_certification', 'id_proof', 'background_check', 'rating_feedback'
    ];

    if (in_array($field, $allowed_fields)) {
        $stmt = $conn->prepare("UPDATE users SET `$field` = ? WHERE id = ?");
        $stmt->bind_param("si", $value, $volunteer_id);
        if ($stmt->execute()) {
            echo "success";
        } else {
            echo "error";
        }
    } else {
        echo "invalid field";
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Profile</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
            transition: background-color 0.5s, color 0.5s;
            font-family: 'Arial', sans-serif;
        }
        .dark-mode {
            background-color: #1e1e2f !important;
            color: #f1f1f1;
        }
        .container {
            margin-top: 30px;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            animation: fadeIn 1s ease forwards;
            opacity: 0;
        }
        .dark-mode .container {
            background-color: #2b2b3c;
        }
        @keyframes fadeIn {
            from {opacity: 0; transform: translateY(20px);}
            to {opacity: 1; transform: translateY(0);}
        }
        .form-section {
            margin-bottom: 20px;
            padding: 15px;
            background: #f9f9f9;
            border-radius: 8px;
        }
        .dark-mode .form-section {
            background: #38384d;
        }
        h2, h3 {
            color: #007bff;
        }
        .dark-mode h2, .dark-mode h3 {
            color: #66d9ef;
        }
        .save-status {
            font-size: 0.9em;
            margin-left: 10px;
            display: inline-block;
            color: green;
        }
        footer {
            background: #007bff;
            color: white;
            text-align: center;
            padding: 15px 0;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="#">Rescue Connect</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item"><a class="nav-link" href="volunteer_dashboard.php">Dashboard</a></li>
      <li class="nav-item active"><a class="nav-link" href="#">My Profile</a></li>
      <li class="nav-item"><a class="nav-link" href="user_logout.php">Logout</a></li>
      <li class="nav-item">
        <button class="btn btn-sm btn-light ml-3" onclick="toggleDarkMode()">
          <i class="bi bi-moon-stars-fill"></i> Dark Mode
        </button>
      </li>
    </ul>
  </div>
</nav>

<div class="container">
    <h2 class="text-center mb-4">Update Your Profile</h2>
    <form id="profileForm">
        <div class="row form-section">
            <div class="col-md-6">
                <label><i class="bi bi-person-fill"></i> Name</label>
                <input type="text" name="name" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['name']); ?>">
            </div>
            <div class="col-md-6">
                <label><i class="bi bi-envelope-fill"></i> Email</label>
                <input type="email" name="email" id="email" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['email']); ?>">
            </div>
            <div class="col-md-6 mt-3">
                <label><i class="bi bi-telephone-fill"></i> Phone</label>
                <input type="text" name="phone" id="phone" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['phone']); ?>">
            </div>
            <div class="col-md-6 mt-3">
                <label><i class="bi bi-calendar-date"></i> Age</label>
                <input type="number" name="age" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['age']); ?>">
            </div>
        </div>

        <!-- Emergency Contact -->
        <div class="row form-section">
            <div class="col-md-6">
                <label>Emergency Contact Name</label>
                <input type="text" name="emergency_contact_name" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['emergency_contact_name']); ?>">
            </div>
            <div class="col-md-6">
                <label>Emergency Contact Phone</label>
                <input type="text" name="emergency_contact_phone" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['emergency_contact_phone']); ?>">
            </div>
        </div>

        <!-- Location, Skills, etc. -->
        <div class="row form-section">
            <div class="col-md-6">
                <label>Location</label>
                <input type="text" name="location" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['location']); ?>">
            </div>
            <div class="col-md-6">
                <label>Skills/Expertise</label>
                <input type="text" name="skills_expertise" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['skills_expertise']); ?>">
            </div>
        </div>

        <div class="row form-section">
            <div class="col-md-6">
                <label>Availability</label>
                <input type="text" name="availability" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['availability']); ?>">
            </div>
            <div class="col-md-6">
                <label>Volunteer History</label>
                <input type="text" name="volunteer_history" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['volunteer_history']); ?>">
            </div>
        </div>

        <!-- More fields to be added below -->
        <div class="row form-section">
            <div class="col-md-6">
                <label>Preferred Task Type</label>
                <input type="text" name="preferred_task_type" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['preferred_task_type']); ?>">
            </div>
            <div class="col-md-6">
                <label>Languages Spoken</label>
                <input type="text" name="languages_spoken" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['languages_spoken']); ?>">
            </div>
        </div>

        <div class="row form-section">
            <div class="col-md-6">
                <label>Medical Conditions</label>
                <input type="text" name="medical_conditions" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['medical_conditions']); ?>">
            </div>
            <div class="col-md-6">
                <label>First Aid Certification</label>
                <input type="text" name="first_aid_certification" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['first_aid_certification']); ?>">
            </div>
        </div>

        <div class="row form-section">
            <div class="col-md-6">
                <label>ID Proof</label>
                <input type="text" name="id_proof" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['id_proof']); ?>">
            </div>
            <div class="col-md-6">
                <label>Background Check</label>
                <input type="text" name="background_check" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['background_check']); ?>">
            </div>
        </div>

        <div class="row form-section">
            <div class="col-md-6">
                <label>Rating/Feedback</label>
                <input type="text" name="rating_feedback" class="form-control auto-save" value="<?= htmlspecialchars($volunteer['rating_feedback']); ?>">
            </div>
        </div>

        <p class="text-success mt-3" id="saveStatus"></p>
    </form>
</div>

<footer>
    &copy; <?= date("Y"); ?> Rescue Connect. All rights reserved.
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<script>
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
}

$('.auto-save').on('blur change', function() {
    let field = $(this).attr('name');
    let value = $(this).val().trim();

    if (field === 'phone' && !/^\d{10}$/.test(value)) {
        alert('Phone must be exactly 10 digits!');
        return;
    }
    if (field === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        alert('Invalid email format!');
        return;
    }

    $.ajax({
        type: 'POST',
        url: 'volunteer_profile.php',
        data: { field: field, value: value },
        success: function(response) {
            if (response.trim() === 'success') {
                $('#saveStatus').text('Saved successfully!').fadeIn().delay(1000).fadeOut();
            } else {
                $('#saveStatus').text('Save failed.').fadeIn().delay(2000).fadeOut();
            }
        }
    });
});
</script>
</body>
</html>
