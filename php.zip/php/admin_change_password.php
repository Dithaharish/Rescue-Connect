<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ../admin_login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_password = $_POST['new_password'];
    $hashed = password_hash($new_password, PASSWORD_DEFAULT);
    
    file_put_contents('admin_password.txt', $hashed);  // saves new hash in a text file

    echo "<script>alert('Password changed successfully!'); window.location.href='admin_dashboard.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Change Admin Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="d-flex align-items-center justify-content-center vh-100 bg-light">

<div class="card p-4 shadow" style="width: 22rem;">
    <h4 class="text-center mb-3">Change Admin Password</h4>
    <form method="POST">
        <div class="form-group">
            <label>New Password</label>
            <input type="password" class="form-control" name="new_password" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Update Password</button>
    </form>
</div>

</body>
</html>

