<?php
session_start();
if ($_SESSION['user_role'] !== 'citizen') {
    header("Location: ../login.html");
    exit();
}
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Donation Summary</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background: #f0f8ff;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            border: none;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 12px;
        }
        .card-header {
            background-color: #007bff;
            color: white;
            font-size: 1.3rem;
            border-radius: 12px 12px 0 0;
        }
    </style>
</head>
<body>
<?php include 'role_navbar.php'; ?>

<div class="container">
    <div class="card">
        <div class="card-header">🧾 Donation Summary</div>
        <div class="card-body">
            <p><strong>Total Donations Made:</strong> ₹ [Your total here]</p>
            <p><strong>Donated This Month:</strong> ₹ [Monthly total]</p>
            <p><strong>Donation History:</strong></p>
            <ul>
                <li>Date: [Date], Amount: ₹ [Amount], Campaign: [Campaign Name]</li>
                <!-- Loop real data here -->
            </ul>
        </div>
    </div>
</div>
</body>
</html>
