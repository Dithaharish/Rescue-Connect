<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../login.html");
    exit();
}
include 'connect.php';

// Fetch reports from the database
$sql = "SELECT * FROM reports";
$result = $conn->query($sql);

// Do not close the connection yet, as you'll need it for the second query

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Reports - Rescue Connect Admin</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Rescue Connect Admin</a>
</nav>

<div class="container mt-5">
    <h2 class="text-center mb-4">View Reports</h2>

    <!-- Table of Reports -->
    <?php if ($result && $result->num_rows > 0): ?>
        <h4>Reports (Table View)</h4>
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Report ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Date Reported</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['report_id']); ?></td>
                        <td><?= htmlspecialchars($row['title']); ?></td>
                        <td><?= htmlspecialchars($row['description']); ?></td>
                        <td><?= htmlspecialchars($row['date_reported']); ?></td>
                        <td>
                            <a href="edit_report.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="delete_report.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this report?')">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No reports found!</p>
    <?php endif; ?>

    <!-- Card view of Reports (Optional) -->
    <h4 class="mt-5">Reports (Card View)</h4>
    <div class="row">
        <?php
        // Re-run the query to display reports in card format
        // This is fine since we're still connected
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($report = $result->fetch_assoc()) {
                echo "<div class='col-md-4 mb-3'>";
                echo "<div class='card shadow-sm border-0'>";
                echo "<div class='card-body'>";
                echo "<h5 class='card-title'>" . htmlspecialchars($report['title']) . "</h5>";
                echo "<p class='card-text'>" . htmlspecialchars($report['description']) . "</p>";
                echo "<p>Status: " . htmlspecialchars($report['status']) . "</p>";
                echo "<a href='edit_report.php?id=" . $report['id'] . "' class='btn btn-warning'>Edit</a>";
                echo "<a href='delete_report.php?id=" . $report['id'] . "' class='btn btn-danger' onclick='return confirm(\"Are you sure you want to delete this report?\")'>Delete</a>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<p>No reports found!</p>";
        }
        ?>
    </div>

</div>

<footer class="bg-primary text-white text-center py-3 mt-5">
    &copy; 2025 Rescue Connect | Admin Panel
</footer>

</body>
</html>

<?php
$conn->close(); // Close the connection now that all queries have been executed
?>
