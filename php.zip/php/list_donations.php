<?php
include 'connect.php';
$result = $conn->query("SELECT id, donor_name, amount, donation_type, date FROM donations");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Donation List - Rescue Connect Admin</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-dark bg-primary">
    <span class="navbar-brand mb-0 h1">Rescue Connect Admin</span>
</nav>

<div class="container mt-5">
    <h2 class="text-center mb-4">Donation Records</h2>
    <div class="table-responsive">
        <table class="table table-hover table-bordered shadow-sm">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Donor Name</th>
                    <th>Amount</th>
                    <th>Type</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']); ?></td>
                        <td><?= htmlspecialchars($row['donor_name']); ?></td>
                        <td>₹<?= htmlspecialchars($row['amount']); ?></td>
                        <td><?= htmlspecialchars($row['donation_type']); ?></td>
                        <td><?= htmlspecialchars($row['date']); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<footer class="bg-primary text-white text-center py-3 mt-5">
    &copy; 2025 Rescue Connect | Admin Panel
</footer>

</body>
</html>

<?php $conn->close(); ?>
