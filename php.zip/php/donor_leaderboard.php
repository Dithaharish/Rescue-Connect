<?php
session_start();
if ($_SESSION['user_role'] !== 'citizen') {
    header("Location: ../login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Donor Leaderboard - Donor Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 20px;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand {
            color: white;
        }
        .container {
            max-width: 900px;
            margin-top: 50px;
        }
        .leaderboard-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 10px 0;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .leaderboard-card h4 {
            color: #007bff;
        }
        .leaderboard-card p {
            font-size: 16px;
        }
    </style>
</head>
<body>
    <?php include 'role_navbar.php'; ?>

    <div class="container">
        <h2>Donor Leaderboard</h2>
        <div class="leaderboard-card">
            <h4>Top Donors</h4>
            <p>This page will display the top donors based on their contributions.</p>
            <p>Feature coming soon!</p>
        </div>
    </div>
</body>
</html>
