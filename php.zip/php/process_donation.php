<?php
session_start();

// Validate CSRF Token
if ($_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die('Invalid CSRF token');
}

// Collect donation details
$campaign_id = intval($_POST['campaign_id']);
$donation_amount = floatval($_POST['donation_amount']);
$payment_method = $_POST['payment_method'];
$donor_name = htmlspecialchars($_POST['donor_name']);
$donor_email = filter_var($_POST['donor_email'], FILTER_VALIDATE_EMAIL);
$donation_message = htmlspecialchars($_POST['donation_message']);

// Validate email
if (!$donor_email) {
    die('Invalid email address');
}

// Database connection
include 'connect.php';

// Prepare the query to insert the donation into the database
$stmt = $conn->prepare("INSERT INTO donations (campaign_id, amount, payment_method, donor_name, donor_email, donation_message, donation_date) VALUES (?, ?, ?, ?, ?, ?, NOW())");
$stmt->bind_param("idssss", $campaign_id, $donation_amount, $payment_method, $donor_name, $donor_email, $donation_message);

if ($stmt->execute()) {
    // Redirect to the user's dashboard after successful donation
    header("Location: citizen_dashboard.php?donation=success");
} else {
    // Handle failure (for example, redirect to an error page)
    header("Location: citizen_dashboard.php?donation=failed");
}

$stmt->close();
$conn->close();
?>
