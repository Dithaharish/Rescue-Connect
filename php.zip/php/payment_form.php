<?php
session_start();
if (!isset($_SESSION['donation_amount'])) {
    header("Location: make_donation.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Complete Your Payment</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { background-color: #f0f8ff; margin: 0; padding: 20px; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .container { max-width: 800px; margin-top: 50px; }
        .payment-form { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        .payment-form input, .payment-form select, .payment-form button { width: 100%; margin-bottom: 10px; }
        .payment-form button { background-color: #007bff; color: white; }
    </style>
</head>
<body>
<?php include 'role_navbar.php'; ?>

<div class="container">
    <h2>Complete Your Payment</h2>
    <div class="payment-form">
        <form method="POST" action="payment_gateway.php">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token']; ?>">

            <div class="form-group">
                <label for="paymentMethod">Choose Payment Method</label>
                <select class="form-control" id="paymentMethod" name="payment_method" required>
                    <option value="">Select Payment Method</option>
                    <option value="credit_card">Credit Card</option>
                    <option value="net_banking">Net Banking</option>
                    <option value="paypal">PayPal</option>
                </select>
            </div>

            <div id="creditCardDetails" class="payment-details" style="display:none;">
                <div class="form-group">
                    <label for="card_number">Card Number</label>
                    <input type="text" class="form-control" id="card_number" name="card_number">
                </div>
                <div class="form-group">
                    <label for="expiry_date">Expiry Date (MM/YY)</label>
                    <input type="text" class="form-control" id="expiry_date" name="expiry_date">
                </div>
                <div class="form-group">
                    <label for="cvv">CVV</label>
                    <input type="text" class="form-control" id="cvv" name="cvv">
                </div>
            </div>

            <div id="netBankingDetails" class="payment-details" style="display:none;">
                <div class="form-group">
                    <label for="bank_name">Bank Name</label>
                    <input type="text" class="form-control" id="bank_name" name="bank_name">
                </div>
                <div class="form-group">
                    <label for="account_number">Account Number</label>
                    <input type="text" class="form-control" id="account_number" name="account_number">
                </div>
                <div class="form-group">
                    <label for="ifsc_code">IFSC Code</label>
                    <input type="text" class="form-control" id="ifsc_code" name="ifsc_code">
                </div>
            </div>

            <div id="paypalDetails" class="payment-details" style="display:none;">
                <p>You will be redirected to PayPal to complete your payment.</p>
            </div>

            <button type="submit" class="btn btn-primary">Proceed to Payment</button>
        </form>
    </div>
</div>

<script>
    document.getElementById('paymentMethod').addEventListener('change', function() {
        document.querySelectorAll('.payment-details').forEach(el => el.style.display = 'none');
        if (this.value === 'credit_card') {
            document.getElementById('creditCardDetails').style.display = 'block';
        } else if (this.value === 'net_banking') {
            document.getElementById('netBankingDetails').style.display = 'block';
        } else if (this.value === 'paypal') {
            document.getElementById('paypalDetails').style.display = 'block';
        }
    });
</script>
</body>
</html>
