<?php
session_start();
if (!isset($_SESSION['volunteer_logged_in'])) {
    header("Location: login.php");
    exit();
}
include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $feedback_message = $_POST['message'];
    $volunteer_id = $_SESSION['volunteer_id'];
    
    $conn->query("INSERT INTO feedback (message, volunteer_id) VALUES ('$feedback_message', '$volunteer_id')");
    $_SESSION['message'] = "Thank you for your feedback!";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Feedback - Volunteer Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f7;
            margin: 0;
            padding: 0;
        }
        /* Navigation Bar */
        .navbar {
            background-color: #007bff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            padding: 12px;
            font-size: 16px;
            font-weight: bold;
        }
        .navbar a:hover {
            background-color: #0056b3;
            border-radius: 8px;
        }
        .navbar .logo {
            font-size: 24px;
            font-weight: bold;
        }

        /* Container for the feedback form */
        .container {
            background: #ffffff;
            max-width: 600px;
            margin: 40px auto;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        textarea {
            width: 100%;
            height: 150px;
            padding: 12px;
            font-size: 1rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            resize: none;
            outline: none;
            box-sizing: border-box;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 1rem;
            cursor: pointer;
            border-radius: 8px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            text-align: center;
            color: #28a745;
            font-weight: bold;
            margin-top: 20px;
        }
        .error-message {
            text-align: center;
            color: #dc3545;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <div class="navbar">
        <div class="logo">Rescue Connect</div>
        <div>
            <a href="volunteer_dashboard.php">Dashboard</a>
            <a href="task_status.php">Task Status</a>
            <a href="upcoming_events.php">Upcoming Events</a>
            <a href="alerts.php">Alerts</a>
            <a href="feedback.php">Feedback</a>
            <a href="user_logout.php">Logout</a>
        </div>
    </div>

    <!-- Feedback Form -->
    <div class="container">
        <h2>Provide Feedback</h2>
        
        <?php if (isset($_SESSION['message'])): ?>
            <p class="message"><?= $_SESSION['message']; ?></p>
        <?php endif; ?>

        <form method="POST">
            <textarea name="message" placeholder="Enter your feedback here..." required></textarea>
            <button type="submit">Submit Feedback</button>
        </form>
    </div>
</body>
</html>
