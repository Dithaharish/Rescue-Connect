<?php
session_start();
if ($_SESSION['user_role'] !== 'citizen') {
    header("Location: ../login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Donation Analytics - Donor Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 20px;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand {
            color: white;
        }
        .container {
            max-width: 1000px;
            margin-top: 50px;
        }
        .analytics-card {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .analytics-card h5 {
            font-weight: bold;
            margin-bottom: 15px;
        }
        .analytics-value {
            font-size: 1.5em;
            color: #007bff;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php include 'role_navbar.php'; ?>

    <div class="container">
        <h2>Donation Analytics</h2>

        <div class="analytics-card">
            <h5>Total Donations</h5>
            <p class="analytics-value">$5,250</p>
        </div>

        <div class="analytics-card">
            <h5>Number of Donations</h5>
            <p class="analytics-value">32</p>
        </div>

        <div class="analytics-card">
            <h5>Average Donation Amount</h5>
            <p class="analytics-value">$164.06</p>
        </div>

        <div class="analytics-card">
            <h5>Most Popular Campaign</h5>
            <p class="analytics-value">Disaster Relief Fund</p>
        </div>

        <div class="analytics-card">
            <h5>Recent Donations</h5>
            <ul>
                <li>John Doe - $100 - 2 days ago</li>
                <li>Jane Smith - $250 - 5 days ago</li>
                <li>Mark Johnson - $50 - 1 week ago</li>
            </ul>
        </div>
    </div>
</body>
</html>
