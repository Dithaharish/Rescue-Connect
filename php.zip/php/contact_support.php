<?php
// Start the session
session_start();

// Check if the user is logged in and has the correct role
if ($_SESSION['user_role'] !== 'citizen') {
    // If the role is not 'citizen', redirect to the login page
    header("Location: ../login.html");
    exit();
}

// Include the database connection
include 'connect.php';

// Handle the form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form values and sanitize them
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $subject = htmlspecialchars($_POST['subject']);
    $message = htmlspecialchars($_POST['message']);

    // Validation: Ensure all fields are filled in
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error_message = "Please fill out all fields.";
    } else {
        // Insert the query into your database (optional: save support messages in a table)
        $sql = "INSERT INTO support_messages (name, email, subject, message, status) 
                VALUES ('$name', '$email', '$subject', '$message', 'pending')";
        
        if ($conn->query($sql) === TRUE) {
            $success_message = "Your message has been sent successfully! Our support team will get back to you soon.";
        } else {
            $error_message = "Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Support - Donor Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 20px;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand {
            color: white;
        }
        .container {
            max-width: 800px;
            margin-top: 50px;
        }
        .contact-form {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .contact-form input,
        .contact-form textarea,
        .contact-form button {
            width: 100%;
            margin-bottom: 10px;
        }
        .contact-form button {
            background-color: #007bff;
            color: white;
        }
        .form-group label {
            font-weight: bold;
        }
        .message {
            padding: 10px;
            margin-top: 15px;
            border-radius: 5px;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
        }
    </style>
</head>
<body>
    <?php include 'role_navbar.php'; ?>

    <div class="container">
        <h2>Contact Support</h2>

        <?php if (!empty($error_message)) { ?>
            <div class="message error">
                <?php echo $error_message; ?>
            </div>
        <?php } elseif (!empty($success_message)) { ?>
            <div class="message success">
                <?php echo $success_message; ?>
            </div>
        <?php } ?>

        <div class="contact-form">
            <form method="POST" action="">

                <!-- Name -->
                <div class="form-group">
                    <label for="name">Your Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>

                <!-- Email -->
                <div class="form-group">
                    <label for="email">Your Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>

                <!-- Subject -->
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" class="form-control" id="subject" name="subject" required>
                </div>

                <!-- Message -->
                <div class="form-group">
                    <label for="message">Your Message</label>
                    <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-custom">Send Message</button>
            </form>
        </div>
    </div>
</body>
</html>
