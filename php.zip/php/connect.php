<?php
$servername = "localhost";
$username = "root";    // Default XAMPP MySQL user
$password = "";        // Default XAMPP password is empty
$database = "rescue_connect";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
