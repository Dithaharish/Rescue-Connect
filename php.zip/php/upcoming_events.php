<?php
session_start();
if (!isset($_SESSION['volunteer_logged_in'])) {
    header("Location: login.php");
    exit();
}
include 'connect.php';

$result = $conn->query("SELECT * FROM events WHERE event_date >= CURDATE() ORDER BY event_date ASC");
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Upcoming Events - Volunteer Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e6f5ea;
            color: #2b3e2f;
        }
        nav {
            background-color: #007bff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            color: white;
        }
        nav a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
            font-weight: bold;
        }
        nav a:hover {
            text-decoration: underline;
        }
        .container {
            max-width: 800px;
            margin: 30px auto;
            background: #ffffff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 25px;
        }
        .event {
            border: 1px solid #007bff;
            background-color: #f0fff4;
            margin-bottom: 15px;
            padding: 15px;
            border-radius: 8px;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .event:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 14px rgba(0,0,0,0.15);
        }
        .event h3 {
            margin: 0;
            color: #007bff;
        }
        .event p {
            margin: 5px 0;
        }
        footer {
            background: #007bff;
            color: white;
            text-align: center;
            padding: 12px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>

<nav>
    <div>Rescue Connect</div>
    <div>
        <a href="volunteer_dashboard.php">Dashboard</a>
        <a href="active_tasks.php">Active Tasks</a>
        <a href="upcoming_events.php">Events</a>
        <a href="user_logout.php">Logout</a>
    </div>
</nav>

<div class="container">
    <h2>Upcoming Events</h2>
    <?php if ($result->num_rows > 0): ?>
        <?php while ($event = $result->fetch_assoc()): ?>
            <div class="event">
                <h3><?= htmlspecialchars($event['event_name']); ?></h3>
                <p><strong>Date:</strong> <?= htmlspecialchars($event['event_date']); ?></p>
                <p><strong>Location:</strong> <?= htmlspecialchars($event['event_location']); ?></p>
                <p><?= htmlspecialchars($event['event_description']); ?></p>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p style="text-align:center; color:#555;">No upcoming events at the moment. Stay tuned!</p>
    <?php endif; ?>
</div>

<footer>
    &copy; <?= date('Y'); ?> Rescue Connect — Let's make the world greener together!
</footer>

</body>
</html>
