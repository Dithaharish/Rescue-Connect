<?php
session_start();
if ($_SESSION['user_role'] !== 'citizen') {
    header("Location: ../login.html");
    exit();
}

include 'connect.php';  // Assuming this connects to your database

$email = $_SESSION['email'];  // Assuming you saved it at login
$sql = "SELECT * FROM donations WHERE donor_email = '$email'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Donation Receipts</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f0f8ff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 20px;
        }
        .container {
            margin-top: 50px;
        }
        .table {
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        th {
            background-color: #007bff;
            color: white;
        }
    </style>
</head>
<body>

<?php include 'role_navbar.php'; ?>

<div class="container">
    <h2>Your Donation Receipts</h2>
    <?php if ($result->num_rows > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Donor Name</th>
                    <th>Amount (USD)</th>
                    <th>Donation Type</th>
                    <th>Campaign ID</th>
                    <th>Payment Method</th>
                    <th>Message</th>
                    <th>Donation Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']) ?></td>
                        <td><?= htmlspecialchars($row['donor_name']) ?></td>
                        <td><?= htmlspecialchars($row['amount']) ?></td>
                        <td><?= htmlspecialchars($row['donation_type']) ?></td>
                        <td><?= htmlspecialchars($row['campaign_id']) ?></td>
                        <td><?= htmlspecialchars($row['payment_method']) ?></td>
                        <td><?= htmlspecialchars($row['donation_message']) ?></td>
                        <td><?= htmlspecialchars($row['donation_date']) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No donation records found.</p>
    <?php endif; ?>
</div>

</body>
</html>
