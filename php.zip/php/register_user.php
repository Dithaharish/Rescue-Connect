<?php
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name     = $_POST['name'];       // Full Name
    $email    = $_POST['email'];      // Email
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Password (hashed)
    $role     = $_POST['role'];       // Register As (Role)
    $location = $_POST['location'];   // Location

    // Insert only the basic account creation details
    $stmt = $conn->prepare("INSERT INTO users (name, email, password, role, location) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $password, $role, $location);

    if ($stmt->execute()) {
        echo "<script>
                alert('Account created successfully! You can now log in.');
                window.location.href = '../combined_auth.html#login';
              </script>";
    } else {
        echo "<script>
                alert('Error: Email may already be registered.');
                window.location.href = '../combined_auth.html#signup';
              </script>";
    }

    $stmt->close();
    $conn->close();
}
?>