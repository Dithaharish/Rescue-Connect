<?php
session_start();
if (!isset($_SESSION['volunteer_logged_in'])) {
    header("Location: login.php");
    exit();
}
include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $task_id = $_POST['task_id'];
    $volunteer_id = $_SESSION['volunteer_id'];
    $conn->query("UPDATE tasks SET assigned_volunteer = '$volunteer_id', status = 'assigned' WHERE task_id = '$task_id'");
    $_SESSION['message'] = "You have successfully signed up for this task!";
}

$tasks_result = $conn->query("SELECT * FROM tasks WHERE assigned_volunteer IS NULL");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up for Task - Volunteer Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container {
            margin-top: 60px;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.1);
        }
        h2 {
            color: #007bff;
            margin-bottom: 20px;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .alert-success {
            margin-top: 15px;
        }
        footer {
            text-align: center;
            padding: 12px;
            background: #007bff;
            color: white;
            margin-top: 30px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Rescue Connect</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="volunteer_dashboard.php">Dashboard</a></li>
            <li class="nav-item active"><a class="nav-link" href="#">Sign Up for Task</a></li>
            <li class="nav-item"><a class="nav-link" href="user_logout.php">Logout</a></li>
        </ul>
    </div>
</nav>

<div class="container">
    <h2>Available Tasks</h2>

    <?php 
    if (isset($_SESSION['message'])) {
        echo '<div class="alert alert-success">' . $_SESSION['message'] . '</div>';
        unset($_SESSION['message']);
    }
    ?>

    <?php if ($tasks_result->num_rows > 0): ?>
        <form method="POST">
            <div class="form-group">
                <label for="taskSelect">Select a Task:</label>
                <select class="form-control" id="taskSelect" name="task_id" required>
                    <?php while ($task = $tasks_result->fetch_assoc()): ?>
                        <option value="<?= $task['task_id']; ?>"><?= htmlspecialchars($task['task_name']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Sign Up</button>
        </form>
    <?php else: ?>
        <div class="alert alert-info">No available tasks at the moment.</div>
    <?php endif; ?>
</div>

<footer>
    &copy; <?= date("Y"); ?> Rescue Connect. All rights reserved.
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
