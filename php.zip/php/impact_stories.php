<?php
session_start();
if ($_SESSION['user_role'] !== 'citizen') {
    header("Location: ../login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Impact Stories - Donor Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 20px;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand {
            color: white;
        }
        .container {
            max-width: 900px;
            margin-top: 50px;
        }
        .story-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 10px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .story-card h4 {
            color: #007bff;
        }
        .story-card p {
            font-size: 16px;
        }
    </style>
</head>
<body>
    <?php include 'role_navbar.php'; ?>

    <div class="container">
        <h2>Impact Stories</h2>

        <!-- Example Story 1 -->
        <div class="story-card">
            <h4>Helping Families Affected by Floods</h4>
            <p>We were able to provide food, water, and shelter to over 300 families in the flood-hit regions of our city. The donations from people like you made this possible!</p>
        </div>

        <!-- Example Story 2 -->
        <div class="story-card">
            <h4>Earthquake Relief for Children</h4>
            <p>Through your donations, we provided emergency medical kits, food, and clothing to children who survived the recent earthquake. Your support made a big difference!</p>
        </div>

        <!-- Example Story 3 -->
        <div class="story-card">
            <h4>Assisting Refugees in Need</h4>
            <p>Your donations helped us provide temporary housing and medical assistance to refugees who have fled conflict zones. Thank you for being a part of this life-saving effort.</p>
        </div>
    </div>
</body>
</html>
