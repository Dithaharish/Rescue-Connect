<?php
session_start();
if (!isset($_SESSION['volunteer_logged_in'])) {
    header("Location: login.php");
    exit();
}
include 'connect.php';

$volunteer_id = $_SESSION['volunteer_id'];
$tasks_result = $conn->query("SELECT * FROM tasks WHERE assigned_volunteer = '$volunteer_id'");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Task Status - Volunteer Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e6f2e6;
            margin: 0;
            padding: 0;
        }
        /* Navigation Bar */
        nav {
            background-color: #007bff;
            padding: 10px 0;
            color: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        nav .navbar {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        nav .navbar-brand {
            font-size: 24px;
            color: white;
            text-decoration: none;
        }
        nav .navbar-links {
            display: flex;
            gap: 15px;
        }
        nav .navbar-links a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            font-size: 18px;
        }
        nav .navbar-links a:hover {
            text-decoration: underline;
        }
        /* Main Content */
        .container {
            background: #ffffff;
            max-width: 600px;
            margin: auto;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 20px;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        li {
            background: #f1f8e9;
            margin: 10px 0;
            padding: 12px 18px;
            border-radius: 8px;
            color: #333;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        li span {
            font-weight: bold;
            color: #1b5e20;
        }
        .no-tasks {
            text-align: center;
            color: #757575;
            font-size: 16px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <div class="navbar">
            <a href="#" class="navbar-brand">Rescue Connect</a>
            <div class="navbar-links">
                <a href="volunteer_dashboard.php">Dashboard</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container">
        <h2>Your Task Status</h2>
        <?php if ($tasks_result->num_rows > 0): ?>
            <ul>
                <?php while ($task = $tasks_result->fetch_assoc()): ?>
                    <li><span><?= htmlspecialchars($task['task_name']); ?></span> — Status: <?= htmlspecialchars($task['status']); ?></li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p class="no-tasks">You currently have no assigned tasks.</p>
        <?php endif; ?>
    </div>
</body>
</html>
