<?php
session_start();
if (!isset($_SESSION['volunteer_logged_in'])) {
    header("Location: login.php");
    exit();
}
include 'connect.php';

// Query to get alerts for today or future
$alerts_result = $conn->query("SELECT * FROM alerts WHERE alert_date >= CURDATE()");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Emergency Alerts - Volunteer Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f7;
            margin: 0;
            padding: 20px;
        }
        .container {
            background: #ffffff;
            max-width: 800px;
            margin: auto;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 20px;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        li {
            background: #e9f7ff;
            margin: 12px 0;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }
        .alert-info {
            color: #007bff;
        }
        .alert-date {
            color: #555;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Emergency Alerts</h2>
        <?php if ($alerts_result->num_rows > 0): ?>
            <ul>
                <?php while ($alert = $alerts_result->fetch_assoc()): ?>
                    <li>
                        <div class="alert-info"><?= htmlspecialchars($alert['alert_message']); ?></div>
                        <div class="alert-date">Date: <?= htmlspecialchars($alert['alert_date']); ?></div>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>No upcoming alerts.</p>
        <?php endif; ?>
    </div>
</body>
</html>
