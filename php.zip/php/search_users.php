<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../login.html");
    exit();
}
include 'connect.php';

// Handle search query
$search_query = "";
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $name = $_GET['name'];
    $email = $_GET['email'];
    $role = $_GET['role'];

    // Build query based on user input
    $search_query = "SELECT * FROM users WHERE 1=1";

    if (!empty($name)) {
        $search_query .= " AND name LIKE '%" . $conn->real_escape_string($name) . "%'";
    }
    if (!empty($email)) {
        $search_query .= " AND email LIKE '%" . $conn->real_escape_string($email) . "%'";
    }
    if (!empty($role)) {
        $search_query .= " AND role = '" . $conn->real_escape_string($role) . "'";
    }
}

$result = $conn->query($search_query);
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Search - Rescue Connect Admin</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Rescue Connect Admin</a>
</nav>

<div class="container mt-5">
    <h2 class="text-center mb-4">Search Users</h2>

    <form method="GET" action="search_users.php">
        <div class="form-row">
            <div class="col-md-4">
                <input type="text" class="form-control" name="name" placeholder="Name" />
            </div>
            <div class="col-md-4">
                <input type="email" class="form-control" name="email" placeholder="Email" />
            </div>
            <div class="col-md-4">
                <select class="form-control" name="role">
                    <option value="">Select Role</option>
                    <option value="volunteer">Volunteer</option>
                    <option value="citizen">Citizen</option>
                    <option value="authority">Authority</option>
                </select>
            </div>
        </div>
        <button type="submit" class="btn btn-info mt-3">Search</button>
    </form>

    <?php if ($result && $result->num_rows > 0): ?>
        <table class="table table-striped table-bordered mt-4">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Location</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']); ?></td>
                        <td><?= htmlspecialchars($row['name']); ?></td>
                        <td><?= htmlspecialchars($row['email']); ?></td>
                        <td><?= htmlspecialchars($row['role']); ?></td>
                        <td><?= htmlspecialchars($row['location']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No results found!</p>
    <?php endif; ?>
</div>

<footer class="bg-primary text-white text-center py-3 mt-5">
    &copy; 2025 Rescue Connect | Admin Panel
</footer>

</body>
</html>
