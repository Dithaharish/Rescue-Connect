<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_role'])) {
    header("Location: ../login.html");
    exit();
}

$role = $_SESSION['user_role'];
$name = $_SESSION['user_name'];

echo '<nav class="navbar navbar-expand-lg navbar-dark bg-primary">';
echo '<a class="navbar-brand" href="#">Rescue Connect</a>';
echo '<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">';
echo '<span class="navbar-toggler-icon"></span></button>';
echo '<div class="collapse navbar-collapse" id="navbarNav"><ul class="navbar-nav ml-auto">';

if ($role == 'volunteer') {
    echo '<li class="nav-item"><a class="nav-link" href="volunteer_dashboard.php">Volunteer Home</a></li>';
} elseif ($role == 'citizen') {
    echo '<li class="nav-item"><a class="nav-link" href="donor_dashboard.php">Donor Home</a></li>';
} elseif ($role == 'authority') {
    echo '<li class="nav-item"><a class="nav-link" href="authority_dashboard.php">Authority Home</a></li>';
} elseif ($role == 'admin') {
    echo '<li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Admin Home</a></li>';
}

echo '<li class="nav-item"><a class="nav-link" href="user_change_password.php">Change Password</a></li>';
echo '<li class="nav-item"><a class="nav-link" href="user_logout.php">Logout</a></li>';
echo '</ul></div></nav>';
?>
