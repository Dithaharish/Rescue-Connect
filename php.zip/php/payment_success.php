<?php
session_start();

// Check if the donation was successfully processed (you can customize this logic)
if (!isset($_SESSION['donation_success']) || $_SESSION['donation_success'] !== true) {
    // Redirect to the donor dashboard if donation was not processed
    header("Location: ../dashboard.php");
    exit();
}

// Clear the session variable for donation success
unset($_SESSION['donation_success']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Donation Successful</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 20px;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand {
            color: white;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
        }
        .confirmation-message {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .confirmation-message h2 {
            color: green;
        }
    </style>
</head>
<body>
    <?php include 'role_navbar.php'; ?>

    <div class="container">
        <div class="confirmation-message">
            <h2>Thank You for Your Donation!</h2>
            <p>Your donation has been successfully processed. Your support is greatly appreciated.</p>
            <p><strong>Campaign:</strong> <?php echo htmlspecialchars($_SESSION['campaign_name'] ?? 'N/A'); ?></p>
            <p><strong>Amount Donated:</strong> $<?php echo htmlspecialchars($_SESSION['donation_amount'] ?? '0.00'); ?></p>
            <p><a href="donor_dashboard.php" class="btn btn-primary">Go Back to Dashboard</a></p>
        </div>
    </div>
</body>
</html>
