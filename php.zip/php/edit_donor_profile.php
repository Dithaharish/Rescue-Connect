<?php
session_start();
if ($_SESSION['user_role'] !== 'citizen') {
    header("Location: ../login.html");
    exit();
}

include 'connect.php';

// Get the user_id from the session
$user_id = $_SESSION['user_id'];  // Ensure this session variable is set during login

// Fetch the donor's profile details from the database using prepared statements
$query = "SELECT * FROM donors WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);  // Bind the user_id parameter
$stmt->execute();
$result = $stmt->get_result();
$donor = $result->fetch_assoc();

// Handle the form submission for updating the profile
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $preferred_cause = $_POST['preferred_cause'];
    $emergency_contact_name = $_POST['emergency_contact_name'];
    $emergency_contact_phone = $_POST['emergency_contact_phone'];
    $rating_feedback = $_POST['rating_feedback'];
    $medical_conditions = $_POST['medical_conditions'];
    $first_aid_certification = $_POST['first_aid_certification'];
    $id_proof = $_POST['id_proof'];
    $background_check = $_POST['background_check'];

    // Update the donor's details in the database
    $update_query = "UPDATE donors SET 
                        name = ?, 
                        email = ?, 
                        address = ?, 
                        phone = ?, 
                        preferred_cause = ?, 
                        emergency_contact_name = ?, 
                        emergency_contact_phone = ?, 
                        rating_feedback = ?, 
                        medical_conditions = ?, 
                        first_aid_certification = ?, 
                        id_proof = ?, 
                        background_check = ?
                    WHERE user_id = ?";
    
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("sssssssssssssi", $name, $email, $address, $phone, $preferred_cause, $emergency_contact_name, $emergency_contact_phone, $rating_feedback, $medical_conditions, $first_aid_certification, $id_proof, $background_check, $user_id);

    if ($stmt->execute()) {
        echo "<script>
                alert('Profile updated successfully!');
                window.location.href = 'donor_profile.php';
              </script>";
    } else {
        echo "<script>
                alert('Error updating profile.');
              </script>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Donor Profile - Donor Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 20px;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand {
            color: white;
        }
        .container {
            max-width: 900px;
            margin-top: 50px;
        }
        .form-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 10px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .form-card h3 {
            color: #007bff;
        }
        .btn-custom {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 10px;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <?php include 'role_navbar.php'; ?>

    <div class="container">
        <h2>Edit Your Profile</h2>
        <div class="form-card">
            <h3>Edit Profile</h3>
            <form method="POST" action="edit_donor_profile.php">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($donor['name']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($donor['email']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="address">Address</label>
                    <input type="text" class="form-control" id="address" name="address" value="<?= htmlspecialchars($donor['address']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control" id="phone" name="phone" value="<?= htmlspecialchars($donor['phone']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="preferred_cause">Preferred Cause</label>
                    <input type="text" class="form-control" id="preferred_cause" name="preferred_cause" value="<?= htmlspecialchars($donor['preferred_cause']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="emergency_contact_name">Emergency Contact Name</label>
                    <input type="text" class="form-control" id="emergency_contact_name" name="emergency_contact_name" value="<?= htmlspecialchars($donor['emergency_contact_name']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="emergency_contact_phone">Emergency Contact Phone</label>
                    <input type="text" class="form-control" id="emergency_contact_phone" name="emergency_contact_phone" value="<?= htmlspecialchars($donor['emergency_contact_phone']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="rating_feedback">Rating/Feedback</label>
                    <textarea class="form-control" id="rating_feedback" name="rating_feedback"><?= htmlspecialchars($donor['rating_feedback']); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="medical_conditions">Medical Conditions</label>
                    <textarea class="form-control" id="medical_conditions" name="medical_conditions"><?= htmlspecialchars($donor['medical_conditions']); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="first_aid_certification">First Aid Certification</label>
                    <input type="text" class="form-control" id="first_aid_certification" name="first_aid_certification" value="<?= htmlspecialchars($donor['first_aid_certification']); ?>">
                </div>

                <div class="form-group">
                    <label for="id_proof">ID Proof</label>
                    <input type="text" class="form-control" id="id_proof" name="id_proof" value="<?= htmlspecialchars($donor['id_proof']); ?>">
                </div>

                <div class="form-group">
                    <label for="background_check">Background Check</label>
                    <input type="text" class="form-control" id="background_check" name="background_check" value="<?= htmlspecialchars($donor['background_check']); ?>">
                </div>

                <button type="submit" class="btn-custom">Update Profile</button>
            </form>
        </div>
    </div>
</body>
</html>
