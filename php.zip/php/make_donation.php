<?php
session_start();
if ($_SESSION['user_role'] !== 'citizen') {
    header("Location: ../login.html");
    exit();
}

$campaign_id = isset($_GET['campaign_id']) ? intval($_GET['campaign_id']) : 0;

// Generate a CSRF token to prevent CSRF attacks
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Validate CSRF token
    if ($_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('Invalid CSRF token');
    }

    // Sanitize and store donation details in flat session variables
    $_SESSION['campaign_id'] = intval($_POST['campaign_id']);
    $_SESSION['donation_amount'] = floatval($_POST['donation_amount']);
    $_SESSION['payment_method'] = htmlspecialchars($_POST['payment_method']);
    $_SESSION['donor_name'] = htmlspecialchars($_POST['donor_name']);
    $_SESSION['donor_email'] = filter_var($_POST['donor_email'], FILTER_VALIDATE_EMAIL);
    $_SESSION['donation_message'] = htmlspecialchars($_POST['donation_message']);

    if (!$_SESSION['donor_email']) {
        die('Invalid email address.');
    }

    // Redirect to the payment form
    header("Location: payment_form.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Make a Donation - Donor Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 20px;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand {
            color: white;
        }
        .container {
            max-width: 800px;
            margin-top: 50px;
        }
        .donation-form {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .donation-form input,
        .donation-form select,
        .donation-form button,
        .donation-form textarea {
            width: 100%;
            margin-bottom: 10px;
        }
        .donation-form button {
            background-color: #007bff;
            color: white;
        }
        .form-group label {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php include 'role_navbar.php'; ?>

    <div class="container">
        <h2>Make a Donation</h2>
        <div class="donation-form">
            <form method="POST" action="">
                <!-- CSRF Token Field -->
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token']; ?>">

                <!-- Hidden Campaign ID -->
                <input type="hidden" name="campaign_id" value="<?= $campaign_id ?>">

                <!-- Donation Amount -->
                <div class="form-group">
                    <label for="donationAmount">Donation Amount (in USD)</label>
                    <input type="number" class="form-control" id="donationAmount" name="donation_amount" required min="1" step="any">
                </div>

                <!-- Donation Method -->
                <div class="form-group">
                    <label for="paymentMethod">Payment Method</label>
                    <select class="form-control" id="paymentMethod" name="payment_method" required>
                        <option value="credit_card">Credit Card</option>
                        <option value="paypal">PayPal</option>
                        <option value="bank_transfer">Bank Transfer</option>
                    </select>
                </div>

                <!-- Donor Name -->
                <div class="form-group">
                    <label for="donorName">Your Name</label>
                    <input type="text" class="form-control" id="donorName" name="donor_name" required>
                </div>

                <!-- Donor Email -->
                <div class="form-group">
                    <label for="donorEmail">Your Email</label>
                    <input type="email" class="form-control" id="donorEmail" name="donor_email" required>
                </div>

                <!-- Donation Message -->
                <div class="form-group">
                    <label for="donationMessage">Message (Optional)</label>
                    <textarea class="form-control" id="donationMessage" name="donation_message" rows="4"></textarea>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-custom">Donate Now</button>
            </form>
        </div>
    </div>
</body>
</html>
