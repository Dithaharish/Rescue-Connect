<?php
session_start();
if ($_SESSION['user_role'] !== 'authority') {
    header("Location: ../login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Volunteers</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'role_navbar.php'; ?>
<div class="container mt-5">
    <h2>Manage Volunteers</h2>
    <p>Here you can view, update, or assign volunteers to different tasks and regions.</p>
</div>
</body>
</html>
