<?php
session_start();
if ($_SESSION['user_role'] !== 'authority') {
    header("Location: ../login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Authority Dashboard - Rescue Connect</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f0f8ff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 20px;
        }
        .container {
            margin-top: 30px;
        }
        .feature-buttons a {
            display: block;
            margin: 10px auto;
            padding: 15px 20px;
            width: 100%;
            max-width: 400px;
            border-radius: 8px;
            font-weight: bold;
            text-decoration: none;
            background-color: #007bff;
            color: white;
            transition: 0.3s ease;
        }
        .feature-buttons a:hover {
            background-color: #0056b3;
            color: white;
        }
    </style>
</head>
<body>

<?php include 'role_navbar.php'; ?>

<span class="navbar-brand">Welcome Authority, <?= htmlspecialchars($_SESSION['user_name']); ?>!</span>
<a class="btn btn-outline-light" href="user_logout.php">Logout</a>
</nav>

<div class="container text-center">
    <h1>Disaster Management Panel</h1>
    <p class="lead">View region reports, allocate resources, and supervise volunteers.</p>

    <div class="feature-buttons">
        <a href="dashboard_overview.php">Dashboard Overview</a>
        <a href="manage_volunteers.php">Manage Volunteers</a>
        <a href="manage_donors.php">Manage Donors</a>
        <a href="campaign_management.php">Campaign Management</a>
        <a href="donations_summary.php">Donations Summary</a>
        <a href="authority_notifications.php">Notifications</a>
        <a href="task_assignments.php">Task Assignments</a>
        <a href="impact_reports.php">Impact Reports</a>
        <a href="manage_support_requests.php">Support Requests</a>
        <a href="user_management.php">User Management</a>
    </div>
</div>

</body>
</html>
