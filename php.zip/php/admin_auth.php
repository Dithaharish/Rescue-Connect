<?php
session_start();

// Stored hashed password (generated using password_hash)
$admin_user = "admin";
$stored_hashed_password = '$2y$10$sXDWkZI3JmWWndZkn7ayHu5zI2gxAfXLqCxt4dFyTVpXxE9J1RMeS';  // example hash for 'admin123'

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    if ($user === $admin_user && password_verify($pass, $stored_hashed_password)) {
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin_dashboard.php");
    } else {
        echo "<script>alert('Invalid credentials!'); window.location.href='../admin_login.html';</script>";
    }
}
?>
