<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../login.html");
    exit();
}
include 'connect.php';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $role = $_POST['role'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $location = $_POST['location'];

    // Insert new user into the database
    $stmt = $conn->prepare("INSERT INTO users (role, name, email, password, location) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $role, $name, $email, $password, $location);
    
    if ($stmt->execute()) {
        echo "<script>alert('User added successfully!'); window.location.href='admin_dashboard.php';</script>";
    } else {
        echo "<script>alert('Error adding user.'); window.location.href='add_user.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New User - Rescue Connect</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Rescue Connect Admin</a>
</nav>

<div class="container mt-5">
    <h2 class="text-center mb-4">Add New User</h2>

    <form method="POST" action="add_user.php">
        <div class="form-group">
            <label for="role">Role</label>
            <select class="form-control" id="role" name="role" required>
                <option value="volunteer">Volunteer</option>
                <option value="citizen">Citizen</option>
                <option value="authority">Authority</option>
            </select>
        </div>
        
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>

        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>

        <div class="form-group">
            <label for="location">Location</label>
            <input type="text" class="form-control" id="location" name="location" required>
        </div>

        <button type="submit" class="btn btn-success">Add User</button>
    </form>
</div>

<footer class="bg-primary text-white text-center py-3 mt-5">
    &copy; 2025 Rescue Connect | Admin Panel
</footer>

</body>
</html>
