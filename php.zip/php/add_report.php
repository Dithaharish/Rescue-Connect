<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../login.html");
    exit();
}
include 'connect.php';

// Handle report submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $status = $_POST['status'];

    $sql = "INSERT INTO reports (title, description, status) VALUES ('$title', '$description', '$status')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Report added successfully'); window.location.href='view_reports.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Report - Rescue Connect</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Rescue Connect Admin</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Admin Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="user_logout.php">Logout</a></li>
        </ul>
    </div>
</nav>

<div class="container mt-5">
    <h2 class="text-center mb-4">Add New Report</h2>

    <form method="POST" action="add_report.php">
        <div class="form-group">
            <label for="title">Report Title</label>
            <input type="text" class="form-control" name="title" id="title" required>
        </div>

        <div class="form-group">
            <label for="description">Report Description</label>
            <textarea class="form-control" name="description" id="description" rows="4" required></textarea>
        </div>

        <div class="form-group">
            <label for="status">Status</label>
            <select class="form-control" name="status" id="status" required>
                <option value="pending">Pending</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success">Add Report</button>
    </form>
</div>

<footer class="bg-primary text-white text-center py-3 mt-5">
    &copy; 2025 Rescue Connect | Admin Panel
</footer>

</body>
</html>
