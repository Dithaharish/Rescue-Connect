<?php
session_start();
if ($_SESSION['user_role'] !== 'citizen') {
    header("Location: ../login.html");
    exit();
}

include 'connect.php';
$user_id = $_SESSION['user_id'];  // Make sure user_id is assigned
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Notifications & Alerts - Donor Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 20px;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand {
            color: white;
        }
        .btn-custom {
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            margin-top: 10px;
            padding: 12px 20px;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
        .container {
            max-width: 900px;
            margin-top: 50px;
        }
        .alert-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 10px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .alert-card h4 {
            color: #007bff;
        }
        .alert-card p {
            font-size: 16px;
        }
    </style>
</head>
<body>
    <?php include 'role_navbar.php'; ?>

    <div class="container">
        <h2>Notifications & Alerts</h2>
        <?php
        // Fetch notifications from the database
        $query = "SELECT * FROM notifications WHERE user_id = $user_id ORDER BY created_at DESC";
        $result = $conn->query($query);

        if ($result && $result->num_rows > 0) {
            while ($notification = $result->fetch_assoc()) {
                echo '<div class="alert-card">';
                echo '<h4>' . htmlspecialchars($notification['title']) . '</h4>';
                echo '<p>' . htmlspecialchars($notification['message']) . '</p>';
                echo '<p><small>' . htmlspecialchars($notification['created_at']) . '</small></p>';
                echo '</div>';
            }
        } else {
            echo '<p>No notifications available.</p>';
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
