<?php
session_start();
if (!isset($_SESSION['volunteer_logged_in'])) {
    header("Location: login.php");
    exit();
}
include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $report_title = $_POST['title'];
    $report_description = $_POST['description'];
    $volunteer_id = $_SESSION['volunteer_id'];

    $conn->query("INSERT INTO reports (title, description, volunteer_id) VALUES ('$report_title', '$report_description', '$volunteer_id')");
    $_SESSION['message'] = "Your report has been submitted successfully!";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Report - Volunteer Dashboard</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #e6f5ea;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #2b3e2f;
        }
        nav {
            background-color: #007bff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            color: white;
        }
        nav a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
            font-weight: bold;
        }
        nav a:hover {
            text-decoration: underline;
        }
        .container {
            max-width: 600px;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 25px;
        }
        form label {
            display: block;
            margin: 15px 0 5px;
            font-weight: bold;
        }
        input[type="text"], textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #007bff;
            border-radius: 8px;
            background-color: #f4fbf6;
            resize: vertical;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 20px;
            display: block;
            width: 100%;
            font-size: 16px;
        }
        button:hover {
            background-color: #388e3c;
        }
        .message {
            text-align: center;
            color: #2e7d32;
            font-weight: bold;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<nav>
    <div>Rescue Connect</div>
    <div>
        <a href="volunteer_dashboard.php">Dashboard</a>
        <a href="active_tasks.php">Active Tasks</a>
        <a href="upcoming_events.php">Events</a>
        <a href="logout.php">Logout</a>
    </div>
</nav>

<div class="container">
    <h2>Submit a Report</h2>
    <?php if (isset($_SESSION['message'])): ?>
        <div class="message"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
    <?php endif; ?>

    <form method="POST">
        <label for="title">Title:</label>
        <input type="text" name="title" id="title" required>

        <label for="description">Description:</label>
        <textarea name="description" id="description" rows="5" required></textarea>

        <button type="submit">Submit Report</button>
    </form>
</div>

</body>
</html>
