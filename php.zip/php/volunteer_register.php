<?php
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $volunteer_name = $_POST['volunteer_name'];
    $volunteer_email = $_POST['volunteer_email'];
    $skills = $_POST['skills'];
    $location = $_POST['location'];

    $sql = "INSERT INTO users (name, email, password, role, location) VALUES (?, ?, '', 'volunteer', ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $volunteer_name, $volunteer_email, $location);

    if ($stmt->execute()) {
        echo "<h2>Thank you for registering as a volunteer!</h2>";
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
